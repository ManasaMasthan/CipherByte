// app2.js

function validateForm() {
    var fullname = document.getElementById('fullname').value;
    var email = document.getElementById('email').value;
    var address = document.getElementById('address').value;
    var city = document.getElementById('city').value;
    var state = document.getElementById('state').value;
    var pincode = document.getElementById('pincode').value;
    var cardname = document.getElementById('cardname').value;
    var cardnumber = document.getElementById('cardnumber').value;
    var expmonth = document.getElementById('expmonth').value;
    var expyear = document.getElementById('expyear').value;
    var cvv = document.getElementById('cvv').value;
    var errorMessages = [];

    // Validate full name
    if (fullname === '') {
        errorMessages.push('Please enter your full name.');
    }

    // Validate email
    if (email === '') {
        errorMessages.push('Please enter your email address.');
    } else if (!isValidEmail(email)) {
        errorMessages.push('Please enter a valid email address.');
    }

    // Validate address
    if (address === '') {
        errorMessages.push('Please enter your address.');
    }

    // Validate city
    if (city === '') {
        errorMessages.push('Please enter your city.');
    }

    // Validate state
    if (state === '') {
        errorMessages.push('Please enter your state.');
    }

    // Validate pin code
    if (pincode === '') {
        errorMessages.push('Please enter your pin code.');
    }

    // Validate card name
    if (cardname === '') {
        errorMessages.push('Please enter the name on your card.');
    }

    // Validate card number
    if (cardnumber === '') {
        errorMessages.push('Please enter your credit card number.');
    }

    // Validate expiration month
    if (expmonth === '') {
        errorMessages.push('Please enter the expiration month of your card.');
    }

    // Validate expiration year
    if (expyear === '') {
        errorMessages.push('Please enter the expiration year of your card.');
    }

    // Validate CVV
    if (cvv === '') {
        errorMessages.push('Please enter the CVV.');
    }

    // Display error messages if any
    if (errorMessages.length > 0) {
        var errorMessagesDiv = document.getElementById('errorMessages');
        errorMessagesDiv.innerHTML = '<ul>' + errorMessages.map(msg => '<li>' + msg + '</li>').join('') + '</ul>';
        return false; // Prevent form submission
    }

    // Clear any previous error messages if validation succeeds
    var errorMessagesDiv = document.getElementById('errorMessages');
    errorMessagesDiv.innerHTML = '';

    // Optional: You can submit the form here
    // Example: document.getElementById('myForm').submit();

    // For demonstration purposes, let's show an alert for successful submission
    alert('Form submitted successfully!');

    return false; // Prevent form submission for this example
}

function isValidEmail(email) {
    // Simple email validation using regex
    var regex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
    return regex.test(email);
}
